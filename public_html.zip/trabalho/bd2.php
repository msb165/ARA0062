<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'id14808229_dbmsbborges');
   define('DB_PASSWORD', 'Q#@5ObMhhMy/hZJ*');
   define('DB_DATABASE', 'id14808229_dbaula');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>